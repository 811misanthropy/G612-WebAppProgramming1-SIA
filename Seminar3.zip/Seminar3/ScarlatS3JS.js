function SumNum(a)
{
    let sum = 0;

    for (let nrc = 1; nrc <= a; nrc++)
    {
    sum = sum + nrc;
    }
    console.log("Congratulations! You have successfully created an account");
    console.log("Sum of all numbers up to", a, ":", sum);

}