a = input("Enter the first number: ")
a = int(a)

b = input("Enter the second number: ")
b = int(b)

print(a+b)
print(a-b)
print(a*b)